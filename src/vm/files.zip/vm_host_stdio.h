/* ============================================================
 *  vm_host_stdio.h — host-side stdio bridge for guest VMs
 *
 *  Provides an optional handler for SYS_WRITE that forwards
 *  bytes written by guests to the host process's stdout / stderr
 *  via fwrite.
 *
 *  This is a HOST-ONLY facility — it depends on <stdio.h> being
 *  available with a real stdout. Embedded firmware where the
 *  "host" is the bare-metal startup code can ignore this header
 *  entirely, or provide its own SYS_WRITE handler (e.g., one that
 *  routes bytes to a UART).
 *
 *  Usage:
 *
 *    VmSystem sys;
 *    vm_system_init(&sys, &cfg);
 *    vm_host_install_stdio(&sys);     // adds SYS_WRITE handler
 *    vm_system_load_vm(...);
 *    vm_system_run(...);
 *
 *  Once installed, guests can call SYS_WRITE(1, buf, n) to write
 *  n bytes from buf to host stdout. fd=2 routes to stderr.
 *  Other fds return -EBADF.
 *
 *  Public domain (CC0). No warranty.
 * ============================================================ */

#ifndef VM_HOST_STDIO_H
#define VM_HOST_STDIO_H

#include <stdbool.h>
#include "vm/vm_system.h"

/* Install the SYS_WRITE handler in the given system's ECALL router.
 * Returns true on success, false if the slot is already occupied
 * (caller already installed something at SYS_WRITE). */
bool vm_host_install_stdio(VmSystem *sys);

#endif /* VM_HOST_STDIO_H */
