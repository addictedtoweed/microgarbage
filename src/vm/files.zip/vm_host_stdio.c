/* ============================================================
 *  vm_host_stdio.c — implementation of host stdio bridge
 *  See vm/vm_host_stdio.h for the public contract.
 *
 *  Public domain (CC0). No warranty.
 * ============================================================ */

#include "vm/vm_host_stdio.h"
#include "vm/vm_core.h"
#include "vm/vm_ecall.h"

#include <stdio.h>

/* ============================================================
 *  SYS_WRITE handler
 *
 *    a0 = fd (1 = stdout, 2 = stderr; else -EBADF)
 *    a1 = guest address of buffer
 *    a2 = byte count
 *    → a0 = bytes written, or -EFAULT / -EBADF
 *
 *  The handler resolves the guest buffer through the calling VM's
 *  region map, then writes via host fwrite. A short write (fewer
 *  bytes than requested) propagates through to a0 — the guest
 *  decides whether to retry. EOF is not specifically distinguished;
 *  it just shows up as a short write or a 0 return.
 *
 *  No flushing is performed: stdout's default line-buffering (when
 *  attached to a TTY) or block-buffering (when piped) is in effect.
 *  Guests that need their output to appear immediately should
 *  include a newline at the end of each write. (Future: add an
 *  optional SYS_FFLUSH if there's demand.)
 * ============================================================ */

static void handle_write(VmCpu *cpu, void *system) {
    (void)system;
    if (!cpu) return;

    uint32_t fd      = cpu->regs[VM_REG_A0];
    uint32_t guest_p = cpu->regs[VM_REG_A1];
    uint32_t n       = cpu->regs[VM_REG_A2];

    FILE *dest = NULL;
    if (fd == 1) dest = stdout;
    else if (fd == 2) dest = stderr;
    else {
        cpu->regs[VM_REG_A0] = (uint32_t)-((int32_t)VM_EBADF);
        return;
    }

    /* Empty writes are valid — fwrite of 0 bytes is a no-op and
     * returns 0, which matches the Linux contract. */
    if (n == 0) {
        cpu->regs[VM_REG_A0] = 0;
        return;
    }

    /* Resolve the guest buffer. vm_translate_read returns NULL
     * and sets cpu->trap_cause if the range crosses a region or
     * lies outside any region. We treat that as -EFAULT (a syscall
     * error) rather than letting the trap stand. */
    const void *host_buf = vm_translate_read(cpu, guest_p, n);
    if (!host_buf) {
        cpu->trap_cause = TRAP_NONE;
        cpu->regs[VM_REG_A0] = (uint32_t)-((int32_t)VM_EFAULT);
        return;
    }

    size_t written = fwrite(host_buf, 1, n, dest);
    cpu->regs[VM_REG_A0] = (uint32_t)written;
}

/* ============================================================
 *  Installer
 * ============================================================ */

bool vm_host_install_stdio(VmSystem *sys) {
    if (!sys || !sys->ecall_router) return false;
    return vm_ecall_register(sys->ecall_router, SYS_WRITE, handle_write);
}
