/* ============================================================
 *  vm_runner — host application that runs a guest ELF.
 *
 *  Usage:
 *    vm_runner <path-to-elf>
 *
 *  Loads the given ELF, sets up the VM system with host stdio
 *  enabled (so guests can use SYS_WRITE to print), and runs the
 *  scheduler in a loop. Ctrl-C exits cleanly.
 *
 *  Storage:
 *    - 64 KB shared region for the slab
 *    - 256 KB local arena for VM-local storage (CPU, mailboxes,
 *      data regions, copied code/rodata)
 *  These are static arrays in the binary; they're zeroed at
 *  program load by the OS.
 *
 *  Public domain (CC0). No warranty.
 * ============================================================ */

/* For sigaction() — must precede any system header. */
#define _POSIX_C_SOURCE 200809L

#include "vm/vm_system.h"
#include "vm/vm_host_stdio.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <signal.h>
#include <stdint.h>
#include <stdbool.h>

/* ============================================================
 *  Storage pools
 * ============================================================ */

#define SHARED_BYTES  (64 * 1024)
#define LOCAL_BYTES   (256 * 1024)

static uint8_t g_shared[SHARED_BYTES];
static uint8_t g_local[LOCAL_BYTES];

/* ============================================================
 *  Ctrl-C handling
 *
 *  The signal handler just flips a flag. The scheduler loop
 *  polls it between cycles and exits cleanly when it sees it.
 *  Using a flag (rather than calling exit() from the handler)
 *  avoids any signal-unsafe operations.
 * ============================================================ */

static volatile sig_atomic_t g_stop = 0;

static void on_sigint(int signo) {
    (void)signo;
    g_stop = 1;
}

/* ============================================================
 *  File loader
 * ============================================================ */

static int load_file(const char *path, uint8_t **out_buf, size_t *out_size) {
    FILE *f = fopen(path, "rb");
    if (!f) {
        fprintf(stderr, "vm_runner: cannot open '%s': ", path);
        perror("");
        return -1;
    }
    if (fseek(f, 0, SEEK_END) != 0) { fclose(f); return -1; }
    long sz = ftell(f);
    if (sz < 0)                     { fclose(f); return -1; }
    if (fseek(f, 0, SEEK_SET) != 0) { fclose(f); return -1; }

    uint8_t *buf = (uint8_t *)malloc((size_t)sz);
    if (!buf)                       { fclose(f); return -1; }

    size_t n = fread(buf, 1, (size_t)sz, f);
    fclose(f);
    if (n != (size_t)sz) { free(buf); return -1; }

    *out_buf = buf;
    *out_size = (size_t)sz;
    return 0;
}

/* ============================================================
 *  Main
 * ============================================================ */

int main(int argc, char **argv) {
    if (argc != 2) {
        fprintf(stderr, "usage: %s <path-to-elf>\n", argv[0]);
        return 2;
    }

    /* Catch Ctrl-C so we can stop the scheduler cleanly. */
    struct sigaction sa;
    memset(&sa, 0, sizeof(sa));
    sa.sa_handler = on_sigint;
    sigaction(SIGINT, &sa, NULL);

    /* Load the ELF. */
    uint8_t *elf = NULL;
    size_t elf_size = 0;
    if (load_file(argv[1], &elf, &elf_size) != 0) {
        return 1;
    }

    /* Initialize the VM system. */
    VmSystem sys;
    VmSystemConfig cfg = {
        .shared_storage      = g_shared,
        .shared_storage_size = SHARED_BYTES,
        .local_storage       = g_local,
        .local_storage_size  = LOCAL_BYTES,
        /* baseline_quantum left at default (5000). */
    };
    if (!vm_system_init(&sys, &cfg)) {
        fprintf(stderr, "vm_runner: vm_system_init failed\n");
        free(elf);
        return 1;
    }

    /* Install the optional host stdio bridge so the guest's
     * SYS_WRITE can reach our stdout/stderr. */
    if (!vm_host_install_stdio(&sys)) {
        fprintf(stderr, "vm_runner: vm_host_install_stdio failed\n");
        free(elf);
        return 1;
    }

    /* Load the guest ELF. */
    VmLoadVmResult lr = vm_system_load_vm(&sys, elf, elf_size,
                                           /*data_region=*/16 * 1024,
                                           VM_BACKING_COPY_RAM,
                                           VM_BACKING_COPY_RAM);
    if (lr.code != VM_SYS_OK) {
        fprintf(stderr,
                "vm_runner: load failed (code=%d, load_result=%d)\n",
                lr.code, lr.load_result);
        free(elf);
        return 1;
    }
    fprintf(stderr, "vm_runner: loaded VM %d, running. Press Ctrl-C to exit.\n",
            lr.assigned_vm_id);

    /* Scheduler loop. Check g_stop between cycles. */
    for (;;) {
        if (g_stop) {
            fprintf(stderr, "\nvm_runner: SIGINT received, exiting.\n");
            break;
        }
        VmSchedStepResult r = vm_system_step(&sys);
        if (r == VM_SCHED_ALL_HALTED) {
            fprintf(stderr, "vm_runner: all VMs halted, exiting.\n");
            break;
        }
        /* VM_SCHED_IDLE means no ready VMs but some blocked. For
         * the counter program this won't happen — it never blocks
         * indefinitely. If it does happen (timer waits, etc.) we
         * could sleep here; for now just spin. */
    }

    vm_system_destroy(&sys);
    free(elf);
    return 0;
}
