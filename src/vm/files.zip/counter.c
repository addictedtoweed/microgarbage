/* counter.c — guest program that prints an incrementing counter
 * forever, yielding the CPU between prints so the scheduler can
 * give other VMs a turn.
 *
 * Uses two syscalls:
 *   SYS_WRITE (64)  - host stdout bridge
 *   SYS_YIELD (1040) - relinquish remainder of quantum
 *
 * No libc, no startup. _start is the entry point. The C compiler
 * emits a normal function frame; the loader has already set sp
 * to the top of region 2. */

#define SYS_WRITE  64
#define SYS_YIELD  1040

/* sys_write(fd, buf, n) -> bytes written or -errno. */
static inline int sys_write(int fd, const void *buf, unsigned n) {
    register int      a0 asm("a0") = fd;
    register unsigned a1 asm("a1") = (unsigned)(unsigned long)buf;
    register unsigned a2 asm("a2") = n;
    register int      a7 asm("a7") = SYS_WRITE;
    asm volatile ("ecall" : "+r"(a0) : "r"(a1), "r"(a2), "r"(a7) : "memory");
    return a0;
}

/* sys_yield() -> 0. */
static inline void sys_yield(void) {
    register int a7 asm("a7") = SYS_YIELD;
    asm volatile ("ecall" : : "r"(a7) : "memory");
}

/* Format an unsigned integer into buf in base 10. Writes from
 * the end backwards, returns a pointer to the first character of
 * the written value. buf must be large enough (12 chars handles
 * any uint32_t including null terminator). */
static char *format_u32(unsigned v, char *buf_end) {
    *--buf_end = '\0';
    if (v == 0) {
        *--buf_end = '0';
        return buf_end;
    }
    while (v > 0) {
        *--buf_end = (char)('0' + (v % 10));
        v /= 10;
    }
    return buf_end;
}

/* The actual program. */
void _start(void) {
    /* Use a stack-local buffer rather than a global: avoids needing
     * a .bss section, which would force the loader to allocate
     * region 2 for it. Region 2 is already allocated for the stack,
     * so a stack buffer costs nothing extra. */
    char buf[32];
    unsigned counter = 0;

    for (;;) {
        /* Build "counter: NNN\n" in buf. */
        const char prefix[] = "counter: ";
        const unsigned prefix_len = sizeof(prefix) - 1;

        /* Copy prefix. */
        for (unsigned i = 0; i < prefix_len; i++) {
            buf[i] = prefix[i];
        }

        /* Format the number into a temporary at the end of buf. */
        char numbuf[16];
        char *num = format_u32(counter, numbuf + sizeof(numbuf));
        unsigned num_len = 0;
        while (num[num_len] != '\0') num_len++;

        /* Append number after prefix. */
        for (unsigned i = 0; i < num_len; i++) {
            buf[prefix_len + i] = num[i];
        }
        buf[prefix_len + num_len] = '\n';

        unsigned total = prefix_len + num_len + 1;
        sys_write(1, buf, total);

        counter++;
        sys_yield();
    }
}
